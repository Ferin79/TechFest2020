$(document).ready(function() {
    $('.sidenav').sidenav();
});