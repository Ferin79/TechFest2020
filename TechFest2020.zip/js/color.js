const color = [
  "light-blue lighten-5",
  "amber lighten-4",
  "deep-orange lighten-3",
  "amber lighten-3",
  "cyan lighten-4",
  "teal lighten-4"
];

$("#1").addClass(color[0]);
$("#2").addClass(color[1]);
$("#3").addClass(color[2]);
$("#4").addClass(color[3]);
$("#5").addClass(color[4]);
$("#6").addClass(color[5]);
